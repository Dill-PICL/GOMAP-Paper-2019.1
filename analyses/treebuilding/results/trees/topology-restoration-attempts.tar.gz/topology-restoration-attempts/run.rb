# Script which generates all kinds of possible combinations of species (start with full tree, then remove one at at a time,
# then two at a time, then three at a time etc., in order to find the minimum number of species which need to be removed in
# order to reconstruct the expected cladogram)
# As with all other scripts and analyses, run it from the root folder of the repository.

require "csv"

n_species_remove_min = 0 
n_species_remove_max = 5
index_start = 1

species_root = "Pinus_lambertiana"
species_always_present = [
  "Medicago_truncatula.A17",
  "Medicago_truncatula.R108",
  "Zea_mays.Mo17",
  "Zea_mays.PH207",
  "Zea_mays.W22",
  "Zea_mays.B73.v4"
]
species_add_remove = [
  "Arachis_hypogaea",
  "Brachypodium_distachyon",
  "Cannabis_sativa",
  "Glycine_max",
  "Gossypium_raimondii",
  "Hordeum_vulgare",
  "Oryza_sativa",
  "Phaseolus_vulgaris",
  "Sorghum_bicolor",
  "Triticum_aestivum",
  "Vigna_unguiculata"
]

def build_yaml_string(species)
  yaml = <<-EOF
---
species:
EOF
  species.each {|s| yaml << "- #{s}\n" }

  yaml << <<-EOF
  
parsimony: no
nj: yes

aspects: ["A"]

jackknives:
  n_trees: 100
  percentages: []
...
EOF
end

index = index_start

CSV.open("attempt_results.csv", "wb") do |csv|
  csv << ["id", "n_left_out", "species_present", "species_removed", "expected_topology"]
  (n_species_remove_min..n_species_remove_max).each do |n_species_removed_currently|
    puts "Removing #{n_species_removed_currently}"
    n_species_selected = species_add_remove.length - n_species_removed_currently
    # For each possible combination with that amount of species:
    species_add_remove.combination(n_species_selected).each do |combo|
      combo << species_root
      combo += species_always_present
      puts " Run #{index}"
      IO.write("data/desired_trees/attempt_#{index}.yaml", build_yaml_string(combo))
      `ruby analyses/treebuilding/treebuilding.rb data/desired_trees/attempt_#{index}.yaml`

      csv << [index, n_species_removed_currently, combo.join(";"), (species_add_remove - combo).join(";"), 
              (system("bash analyses/treebuilding/results/topology-restoration-attempts/compareTrees.sh analyses/treebuilding/results/topology-restoration-attempts/expectedTopology.nw analyses/treebuilding/results/trees/attempt_#{index}/nj_A.tree") or system("bash analyses/treebuilding/results/topology-restoration-attempts/compareTrees.sh analyses/treebuilding/results/topology-restoration-attempts/expectedTopology_maizeSwapped.nw analyses/treebuilding/results/trees/attempt_#{index}/nj_A.tree"))]
      csv.flush
      index += 1
    end
  end
end
