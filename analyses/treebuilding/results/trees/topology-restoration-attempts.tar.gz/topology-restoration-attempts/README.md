# Topology Restoration Attempts
These are the scripts and resources used to find the minimum combination of species that need to be removed from the dataset until the Neighbor-joining tree corresponds to the expected topology.
The combination shown in the paper including jackknifing values can be found in the `restored-topology.tar.gz` archive.

Like the other analyses, the script `run.rb` in this folder has to be run from the root folder of the repository.
It creates all possible combinations of species (as per the settings in the beginning of the file) and then calls `compareTrees.sh` to determine whether the created tree corresponds to the expected topology.
That script itself is built around `nw_match` from the [newick utils](https://github.com/tjunier/newick_utils).

The expected topology is saved in `expectedTopology.nw` and then an alternative version in `expectedTopology_maizeSwapped.nw` which we considered equally valid because as we said in the manuscript, within-species relationships are sometimes hard to project in a tree.

The generated trees from our run can be found in `trees` as well as the table `attempt_results.csv` containing the information which species were removed for each attempt and whether the result generated the expected topology.
If you run this script yourself, the trees will be generated in `analyses/treebuilding/results/trees/attempt_$id` like all other trees and the `attempt_results.csv` in your current working directory (which should be the repository root folder).
If you use the same datasets, the results should be identical because the process is deterministic.
