# This script is used to check whether a produced tree is a subtree of the expected
# topology. It's built around nw_match from newick utils (https://github.com/tjunier/newick_utils)
# https://web.archive.org/web/20210409163921/http://cegg.unige.ch/newick_utils

# Argument 1 needs to be full tree, Argument 2 subtree
nw_topology $1 | nw_reroot - "Pinus_lambertiana" > top1
nw_topology $2 | nw_reroot - "Pinus_lambertiana" > top2

if [[ $(nw_match top1 $(cat top2)) ]]; then
  rm top1 top2
  exit 0
else
  rm top1 top2
  exit 1
fi
